import React from 'react';
import "./styles/sidebar.css"
const Sidebar: React.FC = () => {
  return (
    <aside className="sidebar">
     <div className='side'>

        <div id='sideName'>Company Details</div>
     </div>
    </aside>
  );
};

export default Sidebar;
