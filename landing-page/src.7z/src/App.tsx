import React from 'react';
import './App.css';
import Navbar from './component/Navbar';
import Sidebar from './component/Sidebar';
import Main from './component/RightContainer';
const App: React.FC = () => {
  return (
    <div className="App">
      <Navbar />
      <Sidebar/>
      <Main/>
      {/* Rest of your app content goes here */}
    </div>
  );
};

export default App;
